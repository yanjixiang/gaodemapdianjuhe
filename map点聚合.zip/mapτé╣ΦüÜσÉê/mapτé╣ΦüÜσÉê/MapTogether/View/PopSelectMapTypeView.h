//
//  PopSelectMapTypeView.h
//  JmlNewProjectbypush
//
//  Created by 闫继祥 on 2019/9/9.
//  Copyright © 2019 闫继祥. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PopSelectMapTypeView : NSObject
- (void)initViewWithlat:(float)lat lon:(float)lon name:(NSString *)name;
@end

NS_ASSUME_NONNULL_END
