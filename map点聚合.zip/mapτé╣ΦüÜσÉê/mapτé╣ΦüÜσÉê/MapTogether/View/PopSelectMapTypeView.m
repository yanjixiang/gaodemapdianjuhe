//
//  PopSelectMapTypeView.m
//  JmlNewProjectbypush
//
//  Created by 闫继祥 on 2019/9/9.
//  Copyright © 2019 闫继祥. All rights reserved.
//

#import "PopSelectMapTypeView.h"
#import <MapKit/MapKit.h>
#import "JHSheetActionView.h"

@interface PopSelectMapTypeView ()<UIActionSheetDelegate>

@end
@implementation PopSelectMapTypeView

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

- (void)initViewWithlat:(float)lat lon:(float)lon name:(NSString *)name {
    
    NSMutableArray *arr = [NSMutableArray array];
    [arr addObject:@"Apple 地图"];
    if ([self isInstallApp:@"iosamap"]) {
        [arr addObject:@"高德地图"];
    }
    if ([self isInstallApp:@"baidumap"]) {
        [arr addObject:@"百度地图"];
    }
    if ([self isInstallApp:@"qqmap"]) {
        [arr addObject:@"腾讯地图"];
    }
    
    JHSheetActionView *sheetView= [[JHSheetActionView alloc] init];
    sheetView.sheetItems=@[[arr mutableCopy],@[@"取消"]];
    sheetView.callBackCellForRowIndex = ^(NSInteger index) {
        NSString *urlsting=nil;
        CLLocationCoordinate2D  coordinate = CLLocationCoordinate2DMake(lat, lon);
        switch (index) {
                //Apple 地图
            case 1:{
                MKMapItem *currentLocation = [MKMapItem mapItemForCurrentLocation];
                MKMapItem *tolocation = [[MKMapItem alloc] initWithPlacemark:[[MKPlacemark alloc] initWithCoordinate:coordinate addressDictionary:nil]];
                tolocation.name=name;
                [MKMapItem openMapsWithItems:@[currentLocation,tolocation]launchOptions:@{MKLaunchOptionsDirectionsModeKey:MKLaunchOptionsDirectionsModeDriving,MKLaunchOptionsShowsTrafficKey:[NSNumber numberWithBool:YES]}];
            }
                break;
                //高德地图
            case 2:{
                if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"iosamap://"]]) {
                    urlsting =[[NSString stringWithFormat:@"iosamap://path?sourceApplication=applicationName&sid=BGVIS1&did=BGVIS2&dlat=%lf&dlon=%lf&dname=%@&dev=0&t=0",coordinate.latitude,coordinate.longitude,name] stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
                }
                
            }
                break;
                //百度地图
            case 3:{
                if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"baidumap://"]]){
                    //转换百度坐标
                    CLLocationCoordinate2D xcoordinate=[self BD09FromGCJ02:coordinate];
                    urlsting =[[NSString stringWithFormat:@"baidumap://map/direction?origin=我的位置&destination=latlng:%f,%f|name:%@&mode=driving&coord_type=gcj02",xcoordinate.latitude,xcoordinate.longitude,name] stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
                }
                
            }
                break;
                //腾讯地图
            case 4:{
                if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"qqmap://"]]){
                    urlsting =[[NSString stringWithFormat:@"qqmap://map/routeplan?type=drive&from=我的位置&to=%@&tocoord=%lf,%lf&referer=OB4BZ-D4W3U-B7VVO-4PJWW-6TKDJ-WPB77",name,coordinate.latitude,coordinate.longitude] stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
                }
                
            }
                break;
                
            default:
                break;
        }
        //打开应用内跳转
        if(!urlsting) return;
        if (@available(iOS 10.0, *)) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlsting] options:@{} completionHandler:nil];
        } else {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlsting]];
        }
        
    };
    [sheetView showView];
}
- (BOOL)isInstallApp:(NSString *)appString {
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@://",appString]]]){
        return YES;
    }else {
        return NO;
    }
    
}

// 高德坐标转百度坐标(vc内)
- (CLLocationCoordinate2D)BD09FromGCJ02:(CLLocationCoordinate2D)coor {
    CLLocationDegrees x_pi = 3.14159265358979324 * 3000.0 / 180.0;
    CLLocationDegrees x = coor.longitude, y = coor.latitude;
    CLLocationDegrees z = sqrt(x * x + y * y) + 0.00002 * sin(y * x_pi);
    CLLocationDegrees theta = atan2(y, x) + 0.000003 * cos(x * x_pi);
    CLLocationDegrees bd_lon = z * cos(theta) + 0.0065;
    CLLocationDegrees bd_lat = z * sin(theta) + 0.006;
    return CLLocationCoordinate2DMake(bd_lat, bd_lon);
}


@end
