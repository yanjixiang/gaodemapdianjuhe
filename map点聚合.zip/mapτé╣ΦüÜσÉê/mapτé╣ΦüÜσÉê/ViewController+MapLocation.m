//
//  ViewController+MapLocation.m
//  map点聚合
//
//  Created by 闫继祥 on 2019/11/6.
//  Copyright © 2019 闫继祥. All rights reserved.
//

#import "ViewController+MapLocation.h"
#define DefaultLocationTimeout  6
#define DefaultReGeocodeTimeout 3



@implementation ViewController (MapLocation)
- (void)initMap {
    
    [self initMapView];
    
    [self configLocationManager];
    [self startSerialLocation];
    
}
- (void)configLocationManager
{
    self.locationManager = [[AMapLocationManager alloc] init];
    
    [self.locationManager setDelegate:self];
    
    [self.locationManager setDesiredAccuracy:kCLLocationAccuracyHundredMeters];
    
    [self.locationManager setLocationTimeout:6];
    
    [self.locationManager setReGeocodeTimeout:3];
    [self.locationManager setDesiredAccuracy:10];
}
#pragma mark - Initialization
- (void)initMapView
{
    if (self.mapView == nil)
    {
        
        CGRect rectOfStatusbar;
        if (@available(iOS 13.0, *)) {
            UIStatusBarManager *statusBarManager = [UIApplication sharedApplication].keyWindow.windowScene.statusBarManager;
           rectOfStatusbar  = statusBarManager.statusBarFrame;
          
        }else {
            rectOfStatusbar = [[UIApplication sharedApplication] statusBarFrame];

        }
        
        CGFloat h = rectOfStatusbar.size.height+self.navigationController.navigationBar.frame.size.height;
        
        self.mapView = [[MAMapView alloc] initWithFrame:CGRectMake(0, h, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-h)];
        //        self.mapView.allowsAnnotationViewSorting = NO;
        self.mapView.delegate = self;
        //        self.mapView.showsUserLocation = YES;
        self.mapView.userTrackingMode = MAUserTrackingModeFollow;
        
        self.mapView.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
        
        [self.view addSubview:self.mapView];
        
        self.mapView.visibleMapRect = MAMapRectMake(220880104, 101476980, 272496, 466656);
        
    }
}
- (void)startSerialLocation
{
    //开始定位
    [self.locationManager startUpdatingLocation];
}

- (void)stopSerialLocation
{
    //停止定位
    [self.locationManager stopUpdatingLocation];
}
- (void)amapLocationManager:(AMapLocationManager *)manager doRequireLocationAuth:(CLLocationManager*)locationManager {
    
}
- (void)amapLocationManager:(AMapLocationManager *)manager didFailWithError:(NSError *)error
{
    //定位错误
    NSLog(@"%s, amapLocationManager = %@, error = %@", __func__, [manager class], error);
}
- (void)amapLocationManager:(AMapLocationManager *)manager didUpdateLocation:(CLLocation *)location
{
    
    //定位结果
    NSLog(@"location:{lat:%f; lon:%f; accuracy:%f}", location.coordinate.latitude, location.coordinate.longitude, location.horizontalAccuracy);
    self.mapView.centerCoordinate = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude);
    [self reloaddataWith:location.coordinate.latitude longitude:location.coordinate.longitude];
//    __weak typeof(self) weakSelf = self;
//    //创建一个译码器
//    CLGeocoder *cLGeocoder = [[CLGeocoder alloc] init];
//    [cLGeocoder reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error) {
//        if (! error) {
//            if ([placemarks count] > 0) {
//                CLPlacemark *place = [placemarks objectAtIndex:0];
//                // 位置名
//                NSLog(@"name,%@",place.name);
//                // 街道
//                NSLog(@"thoroughfare,%@",place.thoroughfare);
//                // 子街道
//                NSLog(@"subThoroughfare,%@",place.subThoroughfare);
//                // 市
//                NSLog(@"locality,%@",place.locality);
//                // 区
//                NSLog(@"subLocality,%@",place.subLocality);
//                // 国家
//                NSLog(@"country,%@",place.country);
//
//            }else if ([placemarks count] == 0) {
//
//            }
//
//        }
       
//    }];
    //停止定位
    [self stopSerialLocation];
}
@end
