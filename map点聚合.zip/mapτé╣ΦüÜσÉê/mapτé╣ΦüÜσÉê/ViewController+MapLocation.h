//
//  ViewController+MapLocation.h
//  map点聚合
//
//  Created by 闫继祥 on 2019/11/6.
//  Copyright © 2019 闫继祥. All rights reserved.
//



#import "ViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ViewController (MapLocation)
- (void)initMap;

@end

NS_ASSUME_NONNULL_END
