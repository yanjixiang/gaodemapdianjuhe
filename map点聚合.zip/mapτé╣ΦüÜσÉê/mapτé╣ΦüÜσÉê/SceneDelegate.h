//
//  SceneDelegate.h
//  map点聚合
//
//  Created by 闫继祥 on 2019/11/6.
//  Copyright © 2019 闫继祥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

