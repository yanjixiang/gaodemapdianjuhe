//
//  ViewController.h
//  map点聚合
//
//  Created by 闫继祥 on 2019/11/6.
//  Copyright © 2019 闫继祥. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MAMapKit/MAMapKit.h>
#import <AMapSearchKit/AMapSearchKit.h>
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <AMapLocationKit/AMapLocationKit.h>
@interface ViewController :UIViewController <MAMapViewDelegate,AMapLocationManagerDelegate>

@property (nonatomic, strong) UIButton *refreshButton;
@property (nonatomic, strong) AMapLocationManager *locationManager;
@property (nonatomic, strong) MAMapView *mapView;

@property (nonatomic, strong) MAPointAnnotation *pointAnnotaiton;
- (void)reloaddataWith:(CGFloat)latitude longitude:(CGFloat)longitude;


@end

