//
//  ViewController.m
//  map点聚合
//
//  Created by 闫继祥 on 2019/11/6.
//  Copyright © 2019 闫继祥. All rights reserved.
//

#import "ViewController.h"
#import "CoordinateQuadTree.h"
#import "ClusterAnnotation.h"

#import "ClusterAnnotationView.h"
#import "ClusterTableViewCell.h"
#import "CustomCalloutView.h"
#import <AMapSearchKit/AMapCommonObj.h>
#import "ViewController+MapLocation.h"
#import "PopSelectMapTypeView.h"

#define kCalloutViewMargin  -12
@interface ViewController ()<CustomCalloutViewTapDelegate,UIGestureRecognizerDelegate>
@property (nonatomic, strong) CoordinateQuadTree* coordinateQuadTree;

@property (nonatomic, strong) CustomCalloutView *customCalloutView;

@property (nonatomic, strong) NSMutableArray *selectedPoiArray;

@property (nonatomic, assign) BOOL shouldRegionChangeReCalculate;

@property (nonatomic, strong) dispatch_queue_t queue;
@property(nonatomic,strong) NSMutableArray *pointsArr;
@property (nonatomic,strong) NSMutableArray *dataSourceAnnotations;
@property(nonatomic, strong)CLLocationManager *manager;

@end

@implementation ViewController

- (void)reloaddataWith:(CGFloat)latitude longitude:(CGFloat)longitude {
    [self getDataWithlatitude:latitude longitude:longitude];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"点聚合";
    //不加这个，第一次进入app，不弹出地理位置使用权限选择
    self.manager = [[CLLocationManager alloc] init];
    [self.manager requestAlwaysAuthorization];
    [self.manager requestWhenInUseAuthorization];
    _shouldRegionChangeReCalculate = NO;
    
    [self initMap];
  
}

- (void)getDataWithlatitude:(CGFloat)latitude longitude:(CGFloat)longitude {
    
    //地图数据
    self.dataSourceAnnotations = [NSMutableArray array];
    self.pointsArr = [NSMutableArray array];
    NSMutableDictionary *dicP = [NSMutableDictionary dictionary];
    [dicP setValue:[NSString stringWithFormat:@"%f",longitude] forKey:@"longitude"];
    [dicP setValue:[NSString stringWithFormat:@"%f",latitude] forKey:@"latitude"];
    NSLog(@"8888-------%@",dicP);
    //网络数据
//    [PPHTTPRequest HomeFirstMapWithParameters:dicP success:^(id response) {
//        NSArray *array = response[@"info"];
//        [weakSelf handelData:array];
//
//    } failure:^(NSError *error) {
////        [MBProgressHUD showNotice:@"加载失败111" view:self.view];
//    }];
    
    //测试数据
    [self handelData:@[@{@"latitude":@"34.81992",@"longitude":@"113.67219",@"shop_name":@"国基路产业园",@"distance":@"90.4"},
    @{@"latitude":@"34.78923",@"longitude":@"113.68483",@"shop_name":@"郑州市动物园",@"distance":@"80.4"},
   @{@"latitude":@"34.78923",@"longitude":@"113.68483",@"shop_name":@"郑州市动物园",@"distance":@"80.4"},
    @{@"latitude":@"34.608871",@"longitude":@"113.727432",@"shop_name":@"郑州市华南城",@"distance":@"60.4"},
    @{@"latitude":@"34.744911",@"longitude":@"113.66066",@"shop_name":@"郑州市火车站",@"distance":@"50.4"}]];
    
}
- (void)handelData:(NSArray *)array {
    NSLog(@"999999999-----%@",array);
    for (NSDictionary *dicData in array) {
        [self.pointsArr addObject:dicData];
    }
    [self.mapView removeAnnotations:self.dataSourceAnnotations];
    
    [self reloadData];

    for (int i=0; i<self.pointsArr.count; i++) {
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithDictionary:[self.pointsArr objectAtIndex:i]];
        NSString *numStr = [NSString stringWithFormat:@"%d", i];
        [dic setObject:numStr forKey:@"index"];
        [self.pointsArr replaceObjectAtIndex:i withObject:dic];
        
        double coordX = 0;
        double coordY = 0;
        coordX = [[dic objectForKey:@"latitude"] doubleValue];
        coordY = [[dic objectForKey:@"longitude"] doubleValue];
        MAPointAnnotation *pointAnnotation = [[MAPointAnnotation alloc] init];
        pointAnnotation.coordinate = CLLocationCoordinate2DMake(coordX, coordY);
        NSString *str = [NSString stringWithFormat:@"%@",[dic objectForKey:@"shop_name"]];
        if ([str isEqualToString:@"(null)"]||str.length == 0||str == NULL||str == nil||[str isEqualToString:@"<null>"]) {
            str = @"无店铺名称";
        }
        pointAnnotation.title    = str;
        pointAnnotation.subtitle    = [NSString stringWithFormat:@"距离您%@",[dic objectForKey:@"distance"]];
        
        //        pointAnnotation.index = [NSString stringWithFormat:@"%d",i];;
        [self.dataSourceAnnotations addObject:pointAnnotation];
    }
    [self reloadData];
    [self.mapView addAnnotations:_dataSourceAnnotations];
    
}
/* 更新annotation. */
- (void)updateMapViewAnnotationsWithAnnotations:(NSArray *)annotations
{
    /* 用户滑动时，保留仍然可用的标注，去除屏幕外标注，添加新增区域的标注 */
    NSMutableSet *before = [NSMutableSet setWithArray:self.mapView.annotations];
    [before removeObject:[self.mapView userLocation]];
    NSSet *after = [NSSet setWithArray:annotations];
    
    /* 保留仍然位于屏幕内的annotation. */
    NSMutableSet *toKeep = [NSMutableSet setWithSet:before];
    [toKeep intersectSet:after];
    
    /* 需要添加的annotation. */
    NSMutableSet *toAdd = [NSMutableSet setWithSet:after];
    [toAdd minusSet:toKeep];
    
    /* 删除位于屏幕外的annotation. */
    NSMutableSet *toRemove = [NSMutableSet setWithSet:before];
    [toRemove minusSet:after];
    
    /* 更新. */
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.mapView addAnnotations:[toAdd allObjects]];
        [self.mapView removeAnnotations:[toRemove allObjects]];
    });
}

- (void)addAnnotationsToMapView:(MAMapView *)mapView
{
    @synchronized(self)
    {
        if (self.coordinateQuadTree.root == nil || !self.shouldRegionChangeReCalculate)
        {
            NSLog(@"tree is not ready.");
            return;
        }
        
        /* 根据当前zoomLevel和zoomScale 进行annotation聚合. */
        MAMapRect visibleRect = self.mapView.visibleMapRect;
        double zoomScale = self.mapView.bounds.size.width / visibleRect.size.width;
        double zoomLevel = self.mapView.zoomLevel;
        
        /* 也可根据zoomLevel计算指定屏幕距离(以50像素为例)对应的实际距离 进行annotation聚合. */
        /* 使用：NSArray *annotations = [weakSelf.coordinateQuadTree clusteredAnnotationsWithinMapRect:visibleRect withDistance:distance]; */
        //double distance = 50.f * [self.mapView metersPerPointForZoomLevel:self.mapView.zoomLevel];
        
        __weak typeof(self) weakSelf = self;
        dispatch_barrier_async(self.queue, ^{
            
            NSArray *annotations = [weakSelf.coordinateQuadTree clusteredAnnotationsWithinMapRect:visibleRect withZoomScale:zoomScale andZoomLevel:zoomLevel];
            dispatch_async(dispatch_get_main_queue(), ^{
                /* 更新annotation. */
                [weakSelf updateMapViewAnnotationsWithAnnotations:annotations];
            });
        });
    }
}

#pragma mark - CustomCalloutViewTapDelegate

- (void)didDetailButtonTapped:(NSInteger)index
{
    AMapPOI *poi = self.selectedPoiArray[index];
    [[PopSelectMapTypeView alloc] initViewWithlat:poi.location.latitude lon:poi.location.longitude name:poi.name];
}

#pragma mark - MAMapViewDelegate
- (void)mapView:(MAMapView *)mapView didDeselectAnnotationView:(MAAnnotationView *)view
{
    [self.selectedPoiArray removeAllObjects];
    [self.customCalloutView dismissCalloutView];
    self.customCalloutView.delegate = nil;
}

- (void)mapView:(MAMapView *)mapView didSelectAnnotationView:(MAAnnotationView *)view
{
    if ([view.annotation isMemberOfClass:[MAUserLocation class]]) {
        
        return;
    }
    
    ClusterAnnotation *annotation = (ClusterAnnotation *)view.annotation;
    NSLog(@"6666666666666-----%@",annotation);
    if (annotation.count)
    {
        for (AMapPOI *aPoi in annotation.pois)
        {
            [self.selectedPoiArray addObject:aPoi];
        }
        
    }
    [self.customCalloutView setPoiArray:self.selectedPoiArray];
    self.customCalloutView.delegate = self;
    
    // 调整位置
    self.customCalloutView.center = CGPointMake(CGRectGetMidX(view.bounds), -CGRectGetMidY(self.customCalloutView.bounds) - CGRectGetMidY(view.bounds) - kCalloutViewMargin);
    
    [view addSubview:self.customCalloutView];
}

- (void)mapView:(MAMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
    [self addAnnotationsToMapView:self.mapView];
}

- (MAAnnotationView *)mapView:(MAMapView *)mapView viewForAnnotation:(id<MAAnnotation>)annotation
{
    if ([annotation isKindOfClass:[ClusterAnnotation class]])
    {
        /* dequeue重用annotationView. */
        static NSString *const AnnotatioViewReuseID = @"AnnotatioViewReuseID";
        
        ClusterAnnotationView *annotationView = (ClusterAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:AnnotatioViewReuseID];
        
        if (!annotationView)
        {
            annotationView = [[ClusterAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:AnnotatioViewReuseID];
        }
        
        /* 设置annotationView的属性. */
        annotationView.annotation = annotation;
        annotationView.count = [(ClusterAnnotation *)annotation count];
        
        /* 不弹出原生annotation */
        annotationView.canShowCallout = NO;
        
        return annotationView;
    }
    
    return nil;
}

- (void)reloadData {
    
    if (self.dataSourceAnnotations.count == 0)
    {
        return;
    }
    
    NSMutableArray *poiArr = [NSMutableArray array];
    for (MAPointAnnotation *model in self.dataSourceAnnotations)
    {
        AMapPOI *poi = [[AMapPOI alloc]init];
        AMapGeoPoint *loca = [[AMapGeoPoint alloc] init];
        loca.longitude = model.coordinate.longitude;
        loca.latitude = model.coordinate.latitude;
        poi.location = loca;
        poi.subPOIs = @[model];
        poi.name = model.title;
        poi.address = model.subtitle;
        [poiArr addObject:poi];
    }

    @synchronized(self)
    {
        self.shouldRegionChangeReCalculate = NO;
        
        // 清理
        [self.selectedPoiArray removeAllObjects];
        [self.customCalloutView dismissCalloutView];
        
        NSMutableArray *annosToRemove = [NSMutableArray arrayWithArray:self.mapView.annotations];
        NSLog(@"555555555555---000--------%@",self.mapView.annotations);
        [annosToRemove removeObject:self.mapView.userLocation];
        [self.mapView removeAnnotations:annosToRemove];
        
        __weak typeof(self) weakSelf = self;
        dispatch_async(self.queue, ^{
            /* 建立四叉树. */
            [weakSelf.coordinateQuadTree buildTreeWithPOIs:poiArr];
            weakSelf.shouldRegionChangeReCalculate = YES;

            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf addAnnotationsToMapView:weakSelf.mapView];
            });
        });
    }
}


#pragma mark - Life Cycle

- (id)init
{
    if (self = [super init])
    {
        self.coordinateQuadTree = [[CoordinateQuadTree alloc] init];
        
        self.selectedPoiArray = [[NSMutableArray alloc] init];
        
        self.customCalloutView = [[CustomCalloutView alloc] init];
        
        self.queue = dispatch_queue_create("quadQueue", DISPATCH_QUEUE_SERIAL);
    }
    
    return self;
}

- (void)dealloc
{
    [self.coordinateQuadTree clean];
}


@end
